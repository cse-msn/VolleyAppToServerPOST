package mohitn.com.datainsertionappwithpost;

import android.content.Context;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;

class MySingletonClass
{

    private static MySingletonClass mySingletonClass;
    private RequestQueue requestQueue;
    private Context context;

    private MySingletonClass(Context mcontext)
    {
        context = mcontext;
        requestQueue = getRequestQueue();
    }

    public RequestQueue getRequestQueue()
    {
        if(requestQueue==null)
        {
            requestQueue = Volley.newRequestQueue(context.getApplicationContext());
        }
        return requestQueue;
    }

    public static synchronized MySingletonClass getMySingletonClass(Context mcontext)
    {
        if(mySingletonClass==null)
        {
            mySingletonClass = new MySingletonClass(mcontext);
        }
        return mySingletonClass;
    }

    public<T> void addRequest(Request<T> request)
    {
        requestQueue.add(request);
    }



}