package mohitn.com.datainsertionappwithpost;

import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    EditText Username, Password;
    Button SendToServer;

    String ServerURLForPOST = "http://192.168.1.3/save_info_on_server.php";

    AlertDialog.Builder builder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Username = findViewById(R.id.ETUserName);
        Password = findViewById(R.id.ETPassword);
        SendToServer = findViewById(R.id.BTNSend);

        builder = new AlertDialog.Builder(MainActivity.this);

        SendToServer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final String StringUserName, StringPassword;
                StringUserName = Username.getText().toString();
                StringPassword = Password.getText().toString();

                StringRequest stringRequest = new StringRequest(Request.Method.POST, ServerURLForPOST, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        builder.setTitle("Server Response");
                        builder.setMessage("Response : "+ response);
                        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Username.setText("");
                                Password.setText("");
                            }
                        });

                        AlertDialog alertDialog = builder.create();
                        alertDialog.show();
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), "Error...", Toast.LENGTH_SHORT).show();
                        error.printStackTrace();
                    }
                }){
                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        Map<String, String> stringStringMap = new HashMap<String, String>();
                        stringStringMap.put("user_name_in_mobile", StringUserName);
                        stringStringMap.put("password_in_mobile", StringPassword);

                        return stringStringMap;
                    }
                };

                MySingletonClass.getMySingletonClass(getApplicationContext()).addRequest(stringRequest);


            }
        });


    }
}
